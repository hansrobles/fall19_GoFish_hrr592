Hans Matthew Robles
hrr592
11/11/2019
Instructions for using Go Fish

1) After make, executable file name is "go_fish"
2) Output log is inside gofish_results.txt
3) Driver does not take in input files
4) Code is available at github.com/hansrobles/fall19_GoFish_hrr592/settings

